﻿using System.Collections.Generic;
using Project.Domain.Entities.Commons;

namespace Project.Domain.Entities.Users
{
    public class Role : BaseEntity
    {
        //public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<UserRole> UserRoles { get; set; }
    }
}
