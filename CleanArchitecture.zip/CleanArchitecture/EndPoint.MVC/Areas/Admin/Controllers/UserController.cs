﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Project.Application.Services.Users.Commands.EditUser;
using Project.Application.Services.Users.Commands.RegisterUser;
using Project.Application.Services.Users.Commands.RemoveUser;
using Project.Application.Services.Users.Commands.UserStatusChange;
using Project.Application.Services.Users.Queries.GetRoles;
using Project.Application.Services.Users.Queries.GetUsers;

namespace EndPoint.MVC.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class UserController : Controller
    {
        private readonly IGetUsersService _getUsersService;
        private readonly IGetRolesService _getRolesService;
        private readonly IRegisterUserService _registerUserService;
        private readonly IRemoveUserService _removeUserService;
        private readonly IUserStatusChangeService _userStatusChangeService;
        private readonly IEditUserService _editUserService;

        public UserController(IGetUsersService getUsersService,
                              IGetRolesService getRolesService,
                              IRegisterUserService registerUserService,
                              IRemoveUserService removeUserService,
                              IUserStatusChangeService userStatusChangeService,
                              IEditUserService editUserService)
        {
            _getUsersService = getUsersService;
            _getRolesService = getRolesService;
            _registerUserService = registerUserService;
            _removeUserService = removeUserService;
            _userStatusChangeService = userStatusChangeService;
            _editUserService = editUserService;
        }               

        public IActionResult Index(string serchkey, int page = 1)
        {
            return View(_getUsersService.Execute(new RequestGetUsersDto
            {
                Page = page,
                SearchKey = serchkey,
            }));
        }


        [HttpGet]
        public IActionResult Create()
        {
            //data is a list of roles as an Items for dropdownlist, Id is value, Name as a Text to show in dropdownlist
            ViewBag.Roles = new SelectList(_getRolesService.Execute().Data, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(string Email, string FullName, int RoleId, string Password, string RePassword)
        {
            var result = _registerUserService.Execute(new RequestRegisterUseDto
            {
                Email = Email,
                FullName = FullName,
                Roles = new List<RolesRegisterUseDto>()
                   {
                        new RolesRegisterUseDto
                        {
                             Id= RoleId
                        }
                   },
                Password = Password,
                RePassword = RePassword,
            });
            return Json(result);
        }

        [HttpPost]
        public IActionResult Delete(int UserId)
        {
            return Json(_removeUserService.Execute(UserId));
        }

        [HttpPost]
        public IActionResult UserSatusChange(int UserId)
        {
            return Json(_userStatusChangeService.Execute(UserId));
        }

        [HttpPost]
        public IActionResult Edit(int UserId, string Fullname)
        {
            return Json(_editUserService.Execute(new RequestEdituserDto
            {
                Fullname = Fullname,
                UserId = UserId,
            }));
        }

    }
}
