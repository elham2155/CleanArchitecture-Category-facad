﻿using System;
using System.Collections.Generic;
using System.Linq;
using Project.Application.Interfaces.Contexts;
using Project.Common;

namespace Project.Application.Services.Users.Queries.GetUsers
{
    public class GetUsersService : IGetUsersService
    {
        //---connect to DB---since we don't have access to persistance layer,
        //---we shoul use IDatabaseContext from this layer
        private readonly IDatabaseContext _context;
        public GetUsersService(IDatabaseContext context)
        {
            _context = context;
        }
        public ResultGetUsersDto Execute(RequestGetUsersDto request)
        {
            var users = _context.Users.AsQueryable();//---create tsql query
            if (!String.IsNullOrEmpty(request.SearchKey))
            {
                users = users.Where(u => u.FullName.Contains(request.SearchKey) || u.Email.Contains(request.SearchKey));
            }
            int rowsCount = 0;
            var userList= users.ToPaged(request.Page, 20,out rowsCount).Select(u=> new GetUsersDto {
                Email=u.Email,
                FullName=u.FullName,
                Id=u.Id,
                IsActive=u.IsActive
            }).ToList();

            return new ResultGetUsersDto { 
                Rows=rowsCount,
                Users=userList
            };
        }
    }
}
