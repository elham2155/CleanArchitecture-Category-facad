﻿namespace Project.Application.Services.Users.Queries.GetUsers
{
    public class RequestGetUsersDto //Execute Parameters
    {
        public string SearchKey  {get; set; }
        public int Page  {get; set; }
    }
}
