﻿using System.Linq;
using Microsoft.EntityFrameworkCore;
using Project.Application.Interfaces.Contexts;
using Project.Common;
using Project.Common.Dtos;

namespace Project.Application.Services.Users.Commands.UserLogin
{
    public class UserLoginService : IUserLoginService
    {
        private readonly IDatabaseContext _context;
        public UserLoginService(IDatabaseContext context)
        {
            _context = context;
        }
        public ResultDto<ResultUserloginDto> Execute(string Username, string Password)
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                return new ResultDto<ResultUserloginDto>()
                {
                    Data = new ResultUserloginDto()
                    {

                    },
                    IsSuccess = false,
                    Message = "Enter Username or Password",
                };
            }

            var user = _context.Users
                .Include(u => u.UserRoles)
                .ThenInclude(u => u.Role)
                .Where(u => u.Email.Equals(Username) && u.IsActive == true)
                .FirstOrDefault();

            if (user == null)
            {
                return new ResultDto<ResultUserloginDto>()
                {
                    Data = new ResultUserloginDto()
                    {

                    },
                    IsSuccess = false,
                    Message = "There is no user with this email address!",
                };
            }
            //hash the password
            var passwordHasher = new PasswordHasher();
            bool resultVerifyPassword = passwordHasher.VerifyPassword(user.Password, Password);

            if (resultVerifyPassword == false)
            {
                return new ResultDto<ResultUserloginDto>()
                {
                    Data = new ResultUserloginDto()
                    {

                    },
                    IsSuccess = false,
                    Message = "Password is wrong!",
                };
            }


            var roles = "";
            foreach (var item in user.UserRoles)
            {
                roles += $"{item.Role.Name}";
            }


            return new ResultDto<ResultUserloginDto>()
            {
                Data = new ResultUserloginDto()
                {
                    Roles = roles,
                    UserId = user.Id,
                    Name = user.FullName
                },
                IsSuccess = true,
                Message = "You can enter the site",
            };
        }
    }
}
