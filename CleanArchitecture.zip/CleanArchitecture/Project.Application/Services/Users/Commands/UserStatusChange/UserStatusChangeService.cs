﻿using Project.Application.Interfaces.Contexts;
using Project.Common.Dtos;

namespace Project.Application.Services.Users.Commands.UserStatusChange
{
    public class UserStatusChangeService : IUserStatusChangeService
    {
        private readonly IDatabaseContext _context;

        public UserStatusChangeService(IDatabaseContext context)
        {
            _context = context;
        }

        public ResultDto Execute(int UserId)
        {
            var user = _context.Users.Find(UserId);
            if (user == null)
            {
                return new ResultDto
                {
                    IsSuccess = false,
                    Message = "User not found!"
                };
            }

            user.IsActive = !user.IsActive;
            _context.SaveChanges();
            string userstate = user.IsActive == true ? "Active" : "InActive";
            return new ResultDto()
            {
                IsSuccess = true,
                Message = $"Status changed into {userstate}!",
            };
        }

       
    }
}
