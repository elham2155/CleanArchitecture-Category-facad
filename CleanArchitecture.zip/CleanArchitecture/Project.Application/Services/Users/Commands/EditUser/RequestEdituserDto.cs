﻿namespace Project.Application.Services.Users.Commands.EditUser
{
    public class RequestEdituserDto
    {
        public int UserId { get; set; }
        public string Fullname { get; set; }
    }
}
