﻿namespace Project.Application.Services.Users.Commands.RegisterUser
{
    public class RolesRegisterUseDto
    {
        public int Id { get; set; }
    }
}
