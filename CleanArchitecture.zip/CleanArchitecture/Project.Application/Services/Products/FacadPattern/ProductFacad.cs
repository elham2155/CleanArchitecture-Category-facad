﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Application.Interfaces.Contexts;
using Project.Application.Interfaces.FacadPattern;
using Project.Application.Services.Products.Commands.AddNewCategory;
using Project.Application.Services.Products.Queries.GetCategories;

namespace Project.Application.Services.Products.FacadPattern
{
    public class ProductFacad : IProductFacad
    {
        private readonly IDatabaseContext _context;
        //private readonly IHostingEnvironment _environment;
        public ProductFacad(IDatabaseContext context/*, IHostingEnvironment hostingEnvironment*/)
        {
            _context = context;
            //_environment = hostingEnvironment;

        }
        private IAddNewCategoryService _addNewCategory;
        public IAddNewCategoryService AddNewCategoryService
        {
            get
            {                             //if empty
                return _addNewCategory = _addNewCategory ?? new AddNewCategoryService(_context);
            }
        }
        private IGetCategoriesService _getCategoriesService;
        public IGetCategoriesService GetCategoriesService
        {
            get
            {
                return _getCategoriesService = _getCategoriesService ?? new GetCategoriesService(_context);
            }
        }

        //private AddNewProductService _addNewProductService;
        //public AddNewProductService AddNewProductService
        //{
        //    get
        //    {
        //        return _addNewProductService = _addNewProductService ?? new AddNewProductService(_context, _environment);
        //    }
        //}

        //private IGetAllCategoriesService _getAllCategoriesService;
        //public IGetAllCategoriesService GetAllCategoriesService
        //{
        //    get
        //    {
        //        return _getAllCategoriesService = _getAllCategoriesService ?? new GetAllCategoriesService(_context);
        //    }
        //}


        //private IGetProductForAdminService _getProductForAdminService;
        //public IGetProductForAdminService GetProductForAdminService
        //{
        //    get
        //    {
        //        return _getProductForAdminService = _getProductForAdminService ?? new GetProductForAdminService(_context);
        //    }
        //}


        //private IGetProductDetailForAdminService _getProductDetailForAdminService;
        //public IGetProductDetailForAdminService GetProductDetailForAdminService
        //{
        //    get
        //    {
        //        return _getProductDetailForAdminService = _getProductDetailForAdminService ?? new GetProductDetailForAdminService(_context);
        //    }
        //}


        //private IGetProductForSiteService _getProductForSiteService;
        //public IGetProductForSiteService GetProductForSiteService
        //{
        //    get
        //    {
        //        return _getProductForSiteService = _getProductForSiteService ?? new GetProductForSiteService(_context);
        //    }
        //}


        //private IGetProductDetailForSiteService _getProductDetailForSiteService;
        //public IGetProductDetailForSiteService GetProductDetailForSiteService
        //{
        //    get
        //    {
        //        return _getProductDetailForSiteService = _getProductDetailForSiteService ?? new GetProductDetailForSiteService(_context);
        //    }
        //}


    }
}
