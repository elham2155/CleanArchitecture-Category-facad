﻿namespace Project.Application.Services.Products.Queries.GetCategories
{
    public class ParentCategoryDto
    {
        public long Id { get; set; }
        public string name { get; set; }
    }
}
