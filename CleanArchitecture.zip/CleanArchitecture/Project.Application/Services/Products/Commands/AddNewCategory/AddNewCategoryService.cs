﻿using Project.Application.Interfaces.Contexts;
using Project.Common.Dtos;
using Project.Domain.Entities.Products;

namespace Project.Application.Services.Products.Commands.AddNewCategory
{
    public class AddNewCategoryService : IAddNewCategoryService
    {
        private readonly IDatabaseContext _context;

        public AddNewCategoryService(IDatabaseContext context)
        {
            _context = context;
        }
        public ResultDto Execute(int? ParentId, string Name)
        {
            if (string.IsNullOrEmpty(Name))
            {
                return new ResultDto()
                {
                    IsSuccess = false,
                    Message = "Enter category Name!",
                };
            }

            Category category = new Category()
            {
                Name = Name,
                ParentCategory = GetParent(ParentId)
            };
            _context.Categories.Add(category);
            _context.SaveChanges();
            return new ResultDto()
            {
                IsSuccess = true,
                Message = "New category Added!",
            };
        }
        private Category GetParent(int? ParentId)
        {
            return _context.Categories.Find(ParentId);
        }
    }
}
