﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Application.Services.Products.Commands.AddNewCategory;
using Project.Application.Services.Products.Queries.GetCategories;

namespace Project.Application.Interfaces.FacadPattern
{
    public interface IProductFacad
    {
        IAddNewCategoryService AddNewCategoryService { get; }
        IGetCategoriesService GetCategoriesService { get; }
        //AddNewProductService AddNewProductService { get; }
        //IGetAllCategoriesService GetAllCategoriesService { get; }
        /// <summary>
        /// دریافت لیست محصولات
        /// </summary>
        //IGetProductForAdminService GetProductForAdminService { get; }
        //IGetProductDetailForAdminService GetProductDetailForAdminService { get; }
        //IGetProductForSiteService GetProductForSiteService { get; }
        //IGetProductDetailForSiteService GetProductDetailForSiteService { get; }

    }
}
