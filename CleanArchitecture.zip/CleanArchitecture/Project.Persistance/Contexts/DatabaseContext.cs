﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Project.Application.Interfaces.Contexts;
using Project.Common.Roles;
using Project.Domain.Entities.Products;
using Project.Domain.Entities.Users;

namespace Project.Persistance.Contexts
{
    public class DatabaseContext : DbContext , IDatabaseContext
    {
        public DatabaseContext(DbContextOptions options):base(options)
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            SeedData(modelBuilder);

            //to have unique email address for users
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            ApplyQueryFilter(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            //seeding
            modelBuilder.Entity<Role>().HasData(new Role { Id = 1, Name = nameof(UserRolesConst.Admin) });
            modelBuilder.Entity<Role>().HasData(new Role { Id = 2, Name = nameof(UserRolesConst.Operator) });
            modelBuilder.Entity<Role>().HasData(new Role { Id = 3, Name = nameof(UserRolesConst.Customer) });

        }

        private void ApplyQueryFilter(ModelBuilder modelBuilder)
        {
            //Query filter not showing deleted users
            modelBuilder.Entity<User>().HasQueryFilter(u => !u.IsRemoved);
            modelBuilder.Entity<Role>().HasQueryFilter(r => !r.IsRemoved);
            modelBuilder.Entity<UserRole>().HasQueryFilter(ur => !ur.IsRemoved);
            modelBuilder.Entity<Category>().HasQueryFilter(c => !c.IsRemoved);

        }
    }
}
